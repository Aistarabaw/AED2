#pragma once

typedef unsigned int uint;

/* --- Principais structs do programa ---*/

/* Armazena os movimentos */
typedef struct movimento
{
	uint id_conta;
	double montante;
	char* tipo;
	char* data;

	struct movimento* next;
} Movimentos;

/* Sa~o ambas listas-ligadas duplas pois sa~o mais eficientes na altura de remover "nodes" */
typedef struct Cliente {
	uint id;

	char* pin;
	char* nome;
	char* data;
	char* morada;

	/* 70 carateres */
	char* contas_associadas;

	double saldo_global;

	struct Cliente* next;
	struct Cliente* prev;
} Clientes;

typedef struct Conta {
	uint id;
	uint id_owner;

	/* 0 = Ordem, 1 = Prazo */
	short tipo;
	double saldo;

	/* Apontador para o topo da stack dos movimentos,
		ou seja, cada conta possui uma stack com os respetivos movimentos */
	Movimentos* movimentos;

	struct Conta* next;
	struct Conta* prev;
} Contas;
